// # Automat deterministyczny akceptujący język nad alfabetem a, b zakończony sekwencją bba.

// ########################################
// #     Akceptujące stany: q3
// #        
// #           |  a  |  b  |
// #        -------------------
// #     -> q0 |  q0 |  q1 |  
// #        -------------------
// #        q1 |  q0 |  q2 |
// #        -------------------
// #        q2 |  q3 |  q2 |  
// #        -------------------
// #        q3 |  q0 |  q1 |
// #
// ########################################

const ALFABET = "ab"
let Errors = false


const tabela_przejsc = {}

// console.log(tabela_przejsc[0])

var run_btn = document.querySelector('#run')

run_btn.addEventListener('click', () => {
   if (run_btn.classList.contains('running')) {
      location.reload()
   }
   console.log('BTN CLICK')
   const slowo = document.querySelector('#slowo').value
   run(slowo)
   run_btn.classList.add('running')
   run_btn.textContent = "STOP and Reload"
   document.querySelector('#box_dane').style.display = 'none'
})

function check_word_contain_alfabet(slowo) {
   console.log("CHECK START")
   var temp_slowo = [...slowo]
   var temp_alfabet = [...ALFABET]
   temp_slowo.forEach(e => {
      console.log(temp_alfabet.includes(e))
      if (!temp_alfabet.includes(e)) {
         Errors = false
      } 
   })
   console.log("CHECK STOP")
}

function show_letters(slowo) {
   var slowo_array = [...slowo]
   var litery_box = document.querySelector('#box_litery')

   i = 0
   slowo_array.forEach(litera => {
      let span_creator = document.createElement('span')
      span_creator.textContent = litera
      span_creator.classList.add('litera')
      span_creator.setAttribute('data-litera_id', i)
      litery_box.append(span_creator)
      i++
   })
}

function przejscie(slowo) {
   var stany = [...document.querySelectorAll('.stan')]
   var litery = [...document.querySelectorAll('.litera')]
   let ostatni_stan = 0  
   let aktualny_stan = 0
   var slowo_array = [...slowo]
   
   function podswietlenie(litera, delay) {
      // if (delay == 0) stany[0].classList.remove('active')
      setTimeout(() => {
         try {
            litery[delay-1].removeAttribute('style')
         } catch {

         }
         
         stany[ostatni_stan].classList.remove('active')
         stany[tabela_przejsc[aktualny_stan][litera]].classList.add('active')
         litery[delay].style.color = 'red'
         aktualny_stan = tabela_przejsc[aktualny_stan][litera]
         ostatni_stan = aktualny_stan
      
      }, 1000 * delay)
   }

   let delay = 0
   stany[0].classList.remove('active')
   slowo_array.forEach(litera => {
      console.log(litera + "; Aktualny stan: "+ aktualny_stan + " Ostatni Stan: " + ostatni_stan)
      podswietlenie(litera, delay)
      delay++
   })
}

function define_table(alfabet, ilosc_stanow) {
   function div_holder(content = '', editable = 'false', stan = '', litera = '') {
      var div = document.createElement('div')

      div.setAttribute('class', 'tablica_item')
      div.setAttribute('contenteditable', editable)
      if (stan.length > 0 && litera.length > 0) {
         div.setAttribute('data-stan', stan)
         div.setAttribute('data-litera', litera)
      }
      div.innerText = content

      return div
   }
   if (alfabet.length > 0 && ilosc_stanow > 0) {
      const tablica = document.querySelector('#tablica_przejsc')

      tablica.setAttribute('style', `grid-template-columns: repeat(${alfabet.length+1}, 1fr)`)

      tablica.appendChild(div_holder())
      let alfabet_array = [...alfabet]

      alfabet_array.forEach(element => {
         tablica.appendChild(div_holder(element))
      })

      for (let i = 0; i < ilosc_stanow; i++) {
         tablica.appendChild(div_holder(`q${i}`))
         for (let j = 0; j < alfabet.length; j++) {
            tablica.appendChild(div_holder('', 'true', i.toString(), alfabet[j]))
         }
      }
      document.querySelector('#tablica').style.display = 'flex'
      document.querySelector('#step_1').style.display = 'none'
   }
}

const create_table_btn = document.querySelector('#generuj_tablice')

let ilosc_stanow = 0

create_table_btn.addEventListener('click', () => {
   let alfabet = document.querySelector('#alfabet').value
   ilosc_stanow = document.querySelector('#ilosc_stanow').value
   if (alfabet.length > 0 && ilosc_stanow > 0) {
      define_table(alfabet, ilosc_stanow)
   }
})

function create_tabela_przejsc() {
   const cells = [...document.querySelectorAll('[data-stan]')]

   cells.forEach(element => {
      if (tabela_przejsc[element.getAttribute('data-stan')] == undefined) {
         tabela_przejsc[element.getAttribute('data-stan')] = {}
      }
      tabela_przejsc[element.getAttribute('data-stan')][element.getAttribute('data-litera')] = element.innerText
   })
}

function create_automat() {
   const box_automat = document.querySelector('#box_automat')
   const a_stany = document.querySelector('#stany_akceptujace').value
   console.log(a_stany)
   const a_stany_array = a_stany.split(',')
   console.log(a_stany.split(','))
   for(i = 0; i < ilosc_stanow; i++) {
      let div = document.createElement('div')
      div.classList.add('stan')
      if (i == 0) {
         div.classList.add('active')
      }
      if (a_stany_array.includes(i.toString())) {
         console.log(i)
         div.classList.add('accept')
      }
      div.innerHTML = `<span>q${i}</span>`

      box_automat.appendChild(div)
   }
}

const create_program = document.querySelector('#generuj_program')

create_program.addEventListener('click', () => {
   create_tabela_przejsc()
   create_automat()
   document.querySelector('#box_automat').style.display = 'flex'
   document.querySelector('#step_2').style.display = 'flex'
   run_btn.style.display = 'block'
   document.querySelector('#tablica').style.display = 'none'
})


function run(slowo) {
   // var stany = [...document.querySelectorAll('.stan')]
   
   check_word_contain_alfabet(slowo)
   show_letters(slowo)
   przejscie(slowo)
}